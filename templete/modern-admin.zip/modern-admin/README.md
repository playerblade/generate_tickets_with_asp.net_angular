Product Name
---------------
Modern Admin - Clean Bootstrap 4 Dashboard HTML Template + Bitcoin Dashboard


Product Description
-------------------
Modern admin template for Web Application Kit with eCommerce, Sales, Bitcoin & Cryptocurrency Dashboard.

It includes 7 pre-built templates with organized folder structure, clean & commented code, 1500+ pages, 1000+ components, 100+ charts, 50+ advance cards (widgets) and many more. Modern admin provides RTL support.


Online Documentation
--------------------
You will find documentation in your downloaded zip file from ThemeForest. You can access documentation online as well.
Documentation URL: https://pixinvent.com/modern-admin-clean-bootstrap-4-dashboard-html-template/documentation

Change Log
----------
Read CHANGELOG.md file